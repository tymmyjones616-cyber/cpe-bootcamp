import { useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { Copy, Download, AlertCircle, Play, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { PaymentProofModal } from "./PaymentProofModal";

export default function ClientInvoice() {
  const { slug } = useParams<{ slug: string }>();
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  const invoiceQuery = trpc.invoices.getBySlug.useQuery(slug || "");
  const qrCodesQuery = trpc.invoices.getQrCodes.useQuery(invoiceQuery.data?.id || 0, {
    enabled: !!invoiceQuery.data?.id,
  });
  const videosQuery = trpc.invoices.getVideoTutorials.useQuery(invoiceQuery.data?.id || 0, {
    enabled: !!invoiceQuery.data?.id,
  });

  if (invoiceQuery.isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Loading invoice...</div>;
  }

  if (!invoiceQuery.data) {
    return <div className="flex items-center justify-center min-h-screen">Invoice not found</div>;
  }

  const invoice = invoiceQuery.data;
  const qrCodes = qrCodesQuery.data || [];
  const videoTutorials = videosQuery.data || [];

  // Get the first (and only) QR code configured by admin
  const primaryQrCode = qrCodes.length > 0 ? qrCodes[0] : null;

  if (!primaryQrCode) {
    return <div className="flex items-center justify-center min-h-screen">Payment method not configured</div>;
  }

  const handleCopyAddress = (address: string) => {
    if (address) {
      navigator.clipboard.writeText(address);
      toast.success("Address copied to clipboard");
    }
  };

  const truncateAddress = (addr: string) => {
    if (addr.length <= 20) return addr;
    return `${addr.slice(0, 10)}...${addr.slice(-10)}`;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-white border-b border-border">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/cpe-logo.avif" alt="CPE Logo" className="h-8" />
            <h1 className="text-lg font-semibold">Invoice</h1>
          </div>
          <Button variant="ghost" size="sm">
            <Download className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-2xl mx-auto px-4 py-8 space-y-6">
        {/* Amount Display */}
        <div className="text-center space-y-2">
          <div className="text-5xl font-bold tracking-tight">${invoice.amountUsd}</div>
          <div className="text-lg text-muted-foreground">
            Due on {new Date(invoice.dueDate).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
          </div>
        </div>

        {/* Invoice Details */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Invoice Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-sm font-medium text-muted-foreground">Invoice Number</div>
                <div className="font-mono text-sm mt-1">{invoice.invoiceNumber}</div>
              </div>
              <div>
                <div className="text-sm font-medium text-muted-foreground">Date</div>
                <div className="text-sm mt-1">{new Date(invoice.createdAt).toLocaleDateString()}</div>
              </div>
            </div>
            <div className="border-t pt-4">
              <div className="text-sm font-medium text-muted-foreground mb-2">CUSTOMER</div>
              <div className="font-medium">{invoice.clientName}</div>
              <a href={`mailto:${invoice.clientEmail}`} className="text-primary text-sm hover:underline">
                {invoice.clientEmail}
              </a>
            </div>
          </CardContent>
        </Card>

        {/* Invoice Summary Card */}
        <Card className="border-2">
          <CardContent className="pt-6">
            <div className="space-y-3">
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-medium">{invoice.description}</div>
                  <div className="text-sm text-muted-foreground">Service Description</div>
                </div>
                <div className="font-semibold text-lg">${invoice.amountUsd}</div>
              </div>
              <div className="border-t pt-3 flex justify-between">
                <div className="text-sm text-muted-foreground">Subtotal</div>
                <div className="text-sm">${invoice.amountUsd}</div>
              </div>
              <div className="border-t pt-3 flex justify-between">
                <div className="font-semibold">Total Due</div>
                <div className="font-bold text-lg">${invoice.amountUsd}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment Instructions */}
        {invoice.paymentInstructions && (
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="text-base">Payment Instructions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm whitespace-pre-wrap">{invoice.paymentInstructions}</p>
            </CardContent>
          </Card>
        )}

        {/* Payment Method - Single Admin-Configured Option */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Payment Method</CardTitle>
            <CardDescription>Send {primaryQrCode.network.toUpperCase()} to the address below</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Network Badge */}
            <div className="flex items-center justify-between">
              <Badge variant="outline" className="text-base px-3 py-1">
                {primaryQrCode.network.toUpperCase()}
              </Badge>
              {invoice.exchange && (
                <Badge className="bg-blue-600">
                  {invoice.exchange.charAt(0).toUpperCase() + invoice.exchange.slice(1)}
                </Badge>
              )}
            </div>

            {/* QR Code Image */}
            {primaryQrCode.qrCodeUrl && (
              <div className="flex justify-center">
                <img src={primaryQrCode.qrCodeUrl} alt={`${primaryQrCode.network} QR Code`} className="w-48 h-48 border rounded-lg" />
              </div>
            )}

            {/* Wallet Address */}
            <div className="space-y-2">
              <div className="text-sm font-medium text-muted-foreground">Wallet Address</div>
              <div className="flex items-center gap-2 bg-muted p-3 rounded-lg">
                <code className="flex-1 text-sm font-mono break-all">{truncateAddress(primaryQrCode.walletAddress)}</code>
                <Button variant="ghost" size="sm" onClick={() => handleCopyAddress(primaryQrCode.walletAddress)}>
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Warning */}
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>Only send {primaryQrCode.network.toUpperCase()} on this network. Sending other assets may result in loss of funds.</AlertDescription>
            </Alert>

            {/* Payment Submission Button */}
            <Button size="lg" className="w-full" onClick={() => setShowPaymentModal(true)}>
              I Have Made the Payment
            </Button>
          </CardContent>
        </Card>

        {/* Video Tutorials Section */}
        {videoTutorials.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">How to Send Payment</CardTitle>
              <CardDescription>Watch tutorials for different exchanges</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue={videoTutorials[0]?.exchange || ""} className="w-full">
                <TabsList className="grid w-full" style={{ gridTemplateColumns: `repeat(${Math.min(videoTutorials.length, 3)}, 1fr)` }}>
                  {videoTutorials.map((video: any) => (
                    <TabsTrigger key={video.id} value={video.exchange} className="text-xs sm:text-sm">
                      {video.exchange.charAt(0).toUpperCase() + video.exchange.slice(1)}
                    </TabsTrigger>
                  ))}
                </TabsList>

                {videoTutorials.map((video: any) => (
                  <TabsContent key={video.id} value={video.exchange} className="space-y-4 mt-4">
                    {video.title && <h3 className="font-semibold">{video.title}</h3>}
                    {video.description && <p className="text-sm text-muted-foreground">{video.description}</p>}

                    <a href={video.videoUrl} target="_blank" rel="noopener noreferrer">
                      <Button className="w-full gap-2">
                        <Play className="w-4 h-4" />
                        Watch Tutorial
                        <ExternalLink className="w-4 h-4 ml-auto" />
                      </Button>
                    </a>
                  </TabsContent>
                ))}
              </Tabs>
            </CardContent>
          </Card>
        )}

        {/* Payment Proof Modal */}
        <PaymentProofModal
          open={showPaymentModal}
          onOpenChange={setShowPaymentModal}
          invoiceSlug={slug || ""}
          onSuccess={() => invoiceQuery.refetch()}
        />

        {/* Support Section */}
        <Card className="bg-muted">
          <CardContent className="pt-6">
            <h3 className="font-semibold mb-3">NEED HELP?</h3>
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">
                If you need assistance with purchasing cryptocurrency via credit card, e-transfer, or any other payment method, please contact us:
              </p>
              <a href="https://wa.me/14076764098?text=Hi, I need help with invoice" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-green-600 hover:underline">
                <span>💬</span>
                <span>Contact us on WhatsApp</span>
              </a>
              <a href="mailto:cpeonlineacademymanagement@gmail.com" className="flex items-center gap-2 text-primary hover:underline">
                <span>✉️</span>
                <span>cpeonlineacademymanagement@gmail.com</span>
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
